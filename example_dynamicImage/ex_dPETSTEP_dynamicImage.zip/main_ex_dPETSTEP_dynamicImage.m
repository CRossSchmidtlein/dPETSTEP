%% Settings
% Settings will be read from "Dynamic_setSimParameters.m"
% Make sure flag "simSet.FBP_OUT" is set to "true".

% Load example data
load data_ex_dPETSTEP_dynamicImage.mat

%% Run simulation
[data,simSet,FBP4D,OS4D,OSpsf4D,counts,countsNoise,nFWprompts,FWtrues,FWscatters,FWrandoms,wcc] = Dynamic_main_dynamicImage(data,frame,scaleFactor);
                             